#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "librarie.h"

#define NB_VILLES 35
#define NB_ROUTES 50

int main() {
    srand(time(NULL));

    Graphe g;
    g.Ordre = NB_VILLES;

    generer_sommets(&g);
    generer_graphe_avec_routes(&g, NB_ROUTES);
    afficherRoutes(&g);

bool parcouru[N_SOMMETS] = { false };
int sommet_depart = 0;

Afficher_chemin_accessible(&g, sommet_depart, parcouru);
///afficher_sommets_inaccessibles(&g, parcouru);


    //afficher_chemins_accessibles_depuis(&g, 0, parcouru);

   // afficher_sommets_inaccessibles(&g, parcouru);

    return 0;
}
