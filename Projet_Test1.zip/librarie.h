#ifndef LIBRARIE_H
#define LIBRARIE_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_RESSOURCES 10
#define MAX_NOM 30
#define N_SOMMETS 50

static const char *villes[35] = {
    "Antananarivo", "Toamasina", "Fianarantsoa", "Mahajanga", "Toliara",
    "Antsiranana", "Ambatondrazaka", "Moramanga", "Mananjary", "Ambositra",
    "Farafangana", "Nosy Be", "Antalaha", "Sambava", "Marovoay",
    "Soavinandriana", "Ambanja", "Manakara", "Antsirabe", "Ihosy",
    "Miandrivazo", "Bekily", "Vohipeno", "Morondava", "Betioky",
    "Maintirano", "Tsiroanomandidy", "Bealanana", "Miarinarivo", "Mandritsara",
    "Befandriana", "Ambalavao", "Ikongo", "Vavatenina", "Belo-sur-Tsiribihina"
};

static const char *hopitaux[15] = {
    "CHU Joseph Ravoahangy", "CHU Befelatanana", "Hôpital Androva", "CHU Toamasina", "Hôpital Fianarantsoa",
    "Hôpital Ambanja", "Hôpital Toliara", "Hôpital Sambava", "Hôpital Antsirabe", "Hôpital Manakara",
    "Hôpital Morondava", "Hôpital Fort Dauphin", "Hôpital Maintirano", "Hôpital Nosy Be", "Hôpital Tsiroanomandidy"
};

typedef struct {
    char nom[20];
    int poids;
    int valeur_nutritive;
    int priorite;
} Ressource;

typedef enum { MEDICAMENT, NOURRITURE } TypeRessource;

typedef struct {
    int medicament;
    int nourriture;
    int eau;
    int equipement;
} Ressources;

typedef struct {
    char nom[MAX_NOM];
    bool est_hopital;
    int nb_habitants;
    int nb_malade;
    int place_disponible;
    Ressource stock[MAX_RESSOURCES];
    int nb_ressources;
    int nombre;
} Sommet;

typedef enum {
    DETRUITE,
    ENDOMMAGEE,
    NON_ENDOMMAGEE
} EtatRoute;

typedef struct Route {
    int distance;
    EtatRoute etat;
    int capacite_circulation;
    bool fluide;
    bool priorite;
    bool est_endommage;
    bool securise;
    int vehicules_routes;
    int destination;
    struct Route *frere;
} Route;

typedef struct {
    float charge_max;
    float charge_actuelle;
    bool est_en_service;
} Vehicule_Secours;

typedef struct {
    Sommet sommet;
    Route *liste_adjacence;
} NoeudGraphe;

typedef struct {
    NoeudGraphe noeud[N_SOMMETS];
    int Ordre;
} Graphe;

// Prototypes
Route* creer_route();
void generer_sommets(Graphe *g);
void generer_graphe_avec_routes(Graphe *g, int nb_routes_max);


// Mission 1
void afficherRoutes(Graphe *g);
void Afficher_chemin_accessible(Graphe *g, int num_sommet, bool parcouru[N_SOMMETS]);


#endif
