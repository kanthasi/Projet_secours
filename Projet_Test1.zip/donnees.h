#ifndef DONNEES_H
#define DONNEES_H

#define N_VILLES 35
#define N_HOPITAUX 15

static const char *villes[N_VILLES] = {
    "Antananarivo", "Evry", "Ivry", "Mahajanga", "Toliara",
    /*"Antsiranana", "Ambatondrazaka", "Moramanga", "Mananjary", "Ambositra",
    "Farafangana", "Nosy Be", "Antalaha", "Sambava", "Marovoay",
    "Soavinandriana", "Ambanja", "Manakara", "Antsirabe", "Ihosy",
    "Miandrivazo", "Bekily", "Vohipeno", "Morondava", "Betioky",
    "Maintirano", "Tsiroanomandidy", "Bealanana", "Miarinarivo", "Mandritsara",
    "Befandriana", "Ambalavao", "Ikongo", "Vavatenina", "Belo-sur-Tsiribihina"*/
};

static const char *hopitaux[N_HOPITAUX] = {
    "CHU Joseph Ravoahangy", "CHU Befelatanana", "Hôpital Androva", "CHU Toamasina", "Hôpital Fianarantsoa",
    "Hôpital Ambanja", "Hôpital Toliara", "Hôpital Sambava", "Hôpital Antsirabe", "Hôpital Manakara",
    "Hôpital Morondava", "Hôpital Fort Dauphin", "Hôpital Maintirano", "Hôpital Nosy Be", "Hôpital Tsiroanomandidy"
};



#endif
