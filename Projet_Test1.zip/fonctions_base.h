#ifndef FONCTIONS_BASE_H
#define FONCTIONS_BASE_H

//#include "librarie.h"

Route* creer_route();
void generer_sommets(Graphe *g);
void generer_graphe_avec_routes(Graphe *g, int nb_routes_max);

#endif
