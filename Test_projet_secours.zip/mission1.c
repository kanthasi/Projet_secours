#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "librarie.h"

#define NB_VILLES 70
#define NB_ROUTES 50
void afficherRoutes(Graphe *g) {
    printf("\n--- Liste des routes du graphe ---\n");
    for (int i = 0; i < g->Ordre; i++) {
        Route *r = g->noeud[i].liste_adjacence;
        while (r != NULL) {
            const char *etat_str;
            switch (r->etat) {
                case DETRUITE:        etat_str = "DETRUITE"; break;
                case ENDOMMAGEE:      etat_str = "ENDOMMAGÉE"; break;
                case NON_ENDOMMAGEE:  etat_str = "NON ENDOMMAGÉE"; break;
                default:              etat_str = "INCONNU"; break;
            }

            printf("Route de %s vers %s - distance : %dkm - État: %s - Capacité: %d\n",
                g->noeud[i].sommet.nom,
                g->noeud[r->destination].sommet.nom,
                r->distance,
                etat_str,
                r->capacite_circulation);

            r = r->frere;
        }
    }
}

void Afficher_chemin_accessible(Graphe *g, int num_sommet, bool parcouru[N_SOMMETS]) {
    parcouru[num_sommet] = true;
    printf("- Le sommet %s a été parcouru.\n", g->noeud[num_sommet].sommet.nom);

    Route *route = g->noeud[num_sommet].liste_adjacence;
    while (route != NULL) {
        int dest = route->destination;

        if (!parcouru[dest]
            && route->etat != DETRUITE
            && route->vehicules_routes < route->capacite_circulation) {

            printf("- Le chemin entre %s et %s est accessible !\n",
                   g->noeud[num_sommet].sommet.nom,
                   g->noeud[dest].sommet.nom);

            Afficher_chemin_accessible(g, dest, parcouru);
        }

        route = route->frere;
    }
}

void afficher_sommets_inaccessibles(Graphe *g, bool parcouru[N_SOMMETS]) {
    printf("\n=== Sommets inaccessibles après le tremblement de terre ===\n");
    for (int i = 0; i < g->Ordre; i++) {
        if (!parcouru[i]) {
            printf(" - %s\n", g->noeud[i].sommet.nom);
        }
    }
}



  