// mission4_raylib.c : visualisation de la Mission 4 (routes à sécuriser) avec Raylib
#include "raylib.h"
#include "librarie.h"
#include <stdlib.h>

#define SCREEN_WIDTH 1000
#define SCREEN_HEIGHT 800
#define RADIUS 10

// Définitions déjà présentes dans librarie.h :
// typedef struct { int depart, arrivee, distance; } RouteCandidate;
// int comparer_routes(const void *a, const void *b);
// int trouver_representant(int parent[], int sommet);
// void fusion_ensembles(int parent[], int x, int y);

void afficher_mission4_raylib(Graphe *g) {
    // 1) Collecte toutes les routes candidates
    int cout_total = 0;

    int maxRoutes = g->Ordre * g->Ordre;
    RouteCandidate *routes = malloc(maxRoutes * sizeof(*routes));
    int n = 0;
    for (int i = 0; i < g->Ordre; i++) {
        for (Route *r = g->noeud[i].liste_adjacence; r; r = r->frere) {
            routes[n++] = (RouteCandidate){ i, r->destination, r->distance };
            cout_total += routes[i].distance;

        }
    }

    // 2) Tri par distance
    qsort(routes, n, sizeof(*routes), comparer_routes);

    // 3) Union-Find pour Kruskal
    int parent[N_SOMMETS];
    for (int i = 0; i < g->Ordre; i++) parent[i] = i;

    // On stocke les arêtes retenues
    typedef struct { int a, b; } Edge;
    Edge *mst = malloc((g->Ordre-1) * sizeof(*mst));
    int m = 0;
    for (int i = 0; i < n && m < g->Ordre-1; i++) {
        int u = routes[i].depart;
        int v = routes[i].arrivee;
        if (trouver_representant(parent,u) != trouver_representant(parent,v)) {
            fusion_ensembles(parent, u, v);
            mst[m++] = (Edge){ u, v };
        }
    }
    free(routes);

    // 4) Calcul des positions communes
    Vector2 positions[N_SOMMETS];
    compute_positions(g, positions, SCREEN_WIDTH, SCREEN_HEIGHT);

    // 5) Fenêtre Raylib
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Mission 4 - Routes à sécuriser");
    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE);
        char buffer[100];
sprintf(buffer, " routes sécurisées en km: %d", cout_total);
DrawRectangle(10, 10, 350, 30, LIGHTGRAY);
DrawText(buffer, 20, 15, 20, DARKBLUE);


        // 5a) Dessiner toutes les routes en gris clair
        for (int i = 0; i < g->Ordre; i++) {
            for (Route *r = g->noeud[i].liste_adjacence; r; r = r->frere) {
                DrawLineEx(positions[i], positions[r->destination], 1, LIGHTGRAY);
            }
        }

        // 5b) Dessiner les arêtes du MST en vert épais
        for (int i = 0; i < m; i++) {
            Edge e = mst[i];
            DrawLineEx(positions[e.a], positions[e.b], 3, GREEN);
        }

        // 5c) Dessiner les sommets
        for (int i = 0; i < g->Ordre; i++) {
            DrawCircleV(positions[i], RADIUS, DARKBLUE);
            DrawText(g->noeud[i].sommet.nom,
                     positions[i].x + RADIUS,
                     positions[i].y - RADIUS,
                     10, BLACK);
        }

        EndDrawing();
    }

    CloseWindow();
    free(mst);
    
}
