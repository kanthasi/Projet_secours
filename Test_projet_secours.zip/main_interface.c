
#include "raylib.h"
#include "librarie.h"
#include <stdlib.h>
#include <stdio.h>

#define SCREEN_WIDTH 1000
#define SCREEN_HEIGHT 800
#define RADIUS 10

void afficher_graphe_raylib(Graphe *g) {
    // Calculer positions partagées
    Vector2 positions[N_SOMMETS];
    compute_positions(g, positions, SCREEN_WIDTH, SCREEN_HEIGHT);

    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Affichage du Graphe - Projet Secours");
    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE);

        // Dessiner les routes en gris clair sans distinction d'état
        for (int i = 0; i < g->Ordre; i++) {
            for (Route *r = g->noeud[i].liste_adjacence; r; r = r->frere) {
                int j = r->destination;
                DrawLineEx(positions[i], positions[j], 2, LIGHTGRAY);
            }
        }

        // Dessiner les sommets
        for (int i = 0; i < g->Ordre; i++) {
            DrawCircleV(positions[i], RADIUS, DARKBLUE);
            DrawText(g->noeud[i].sommet.nom,
                     positions[i].x + 12,
                     positions[i].y - 5,
                     10, BLACK);
        }

        EndDrawing();
    }

    CloseWindow();
    
}



