#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "librarie.h"

#define NB_VILLES 35
#define NB_ROUTES 50
#define Infini 200
#define AUCUN_Predecesseur -1

int Sommet_DistanceMinimale(int distance[], bool distance_trouvee[]) {
    int min = Infini;
    int indice = 0;

    for (int i = 0; i < N_SOMMETS; i++) {
        if (!distance_trouvee[i] && distance[i] < min) {
            min = distance[i];
            indice = i;
        }
    }
    return indice;
}

void Djikstra(Route *graphe[N_SOMMETS][N_SOMMETS], int Distance[], int SommetDepart, int Predecesseur[]) {
    for (int i = 0; i < N_SOMMETS; i++) {
        Distance[i] = Infini;
        Predecesseur[i] = AUCUN_Predecesseur;
    }
    Distance[SommetDepart] = 0;

    bool visite[N_SOMMETS] = {false};

    for (int passage = 0; passage < N_SOMMETS; passage++) {
        int LeSommet = Sommet_DistanceMinimale(Distance, visite);
        visite[LeSommet] = true;

        for (int voisin = 0; voisin < N_SOMMETS; voisin++) {
            if (graphe[LeSommet][voisin] && !visite[voisin] && graphe[LeSommet][voisin]->etat != DETRUITE) {
                int nouvelle_distance = graphe[LeSommet][voisin]->distance + Distance[LeSommet];
                if (nouvelle_distance < Distance[voisin]) {
                    Distance[voisin] = nouvelle_distance;
                    Predecesseur[voisin] = LeSommet;
                }
            }
        }
    }
}

int Chemin_Djikstra(int SommetArrivee, int Predecesseur[], int chemin[]) {
    int longueur = 0;
    int courant = SommetArrivee;

    while (courant != AUCUN_Predecesseur) {
        chemin[longueur++] = courant;
        courant = Predecesseur[courant];
    }

    for (int i = 0; i < longueur / 2; i++) {
        int tmp = chemin[i];
        chemin[i] = chemin[longueur - 1 - i];
        chemin[longueur - 1 - i] = tmp;
    }

    return longueur;
}

void Endommager(Route *graphe[N_SOMMETS][N_SOMMETS]) {
    int s1 = rand() % N_SOMMETS;
    int s2 = rand() % N_SOMMETS;

    if (s1 != s2 && graphe[s1][s2] && graphe[s1][s2]->etat == NON_ENDOMMAGEE) {
        graphe[s1][s2]->etat = ENDOMMAGEE;
        graphe[s1][s2]->est_endommage = true;
    }
}

void Djikstra_endommagement(Route *graphe[N_SOMMETS][N_SOMMETS], int Distance[], int SommetDepart, int Predecesseur[]) {
    for (int i = 0; i < N_SOMMETS; i++) {
        Distance[i] = Infini;
        Predecesseur[i] = AUCUN_Predecesseur;
    }
    Distance[SommetDepart] = 0;

    bool visite[N_SOMMETS] = {false};

    for (int passage = 0; passage < N_SOMMETS; passage++) {
        int LeSommet = Sommet_DistanceMinimale(Distance, visite);
        visite[LeSommet] = true;

        for (int voisin = 0; voisin < N_SOMMETS; voisin++) {
            if (graphe[LeSommet][voisin] && !visite[voisin] && graphe[LeSommet][voisin]->etat == NON_ENDOMMAGEE) {
                int nouvelle_distance = graphe[LeSommet][voisin]->distance + Distance[LeSommet];
                if (nouvelle_distance < Distance[voisin]) {
                    Distance[voisin] = nouvelle_distance;
                    Predecesseur[voisin] = LeSommet;
                }
            }
        }
    }
}


void afficher_plus_court_chemin(Graphe *g, int sommet_depart, int sommet_arrivee) {
    Route* matrice[N_SOMMETS][N_SOMMETS] = { NULL };
    int distances[N_SOMMETS];
    int predecesseurs[N_SOMMETS];
    int chemin[N_SOMMETS];

    // Construire la matrice d’adjacence
    for (int i = 0; i < g->Ordre; i++) {
        Route* r = g->noeud[i].liste_adjacence;
        while (r != NULL) {
            matrice[i][r->destination] = r;
            r = r->frere;
        }
    }

    Djikstra(matrice, distances, sommet_depart, predecesseurs);
    int longueur = Chemin_Djikstra(sommet_arrivee, predecesseurs, chemin);

    printf("\n=== MISSION 3 : Plus court chemin avec Dijkstra ===\n");
    printf("Chemin le plus court de %s vers %s :\n", 
           g->noeud[sommet_depart].sommet.nom, 
           g->noeud[sommet_arrivee].sommet.nom);

    for (int i = 0; i < longueur; i++) {
        printf(" → %s", g->noeud[chemin[i]].sommet.nom);
    }
    printf("\nDistance totale : %d km\n", distances[sommet_arrivee]);
}

