
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "librarie.h"
#include<math.h>


const char *villes[35] = {
    "Antananarivo", "Toamasina", "Fianarantsoa", "Mahajanga", "Toliara",
    "Antsiranana", "Ambatondrazaka", "Moramanga", "Mananjary", "Ambositra",
    "Farafangana", "Nosy Be", "Antalaha", "Sambava", "Marovoay",
    "Soavinandriana", "Ambanja", "Manakara", "Antsirabe", "Ihosy",
    "Miandrivazo", "Bekily", "Vohipeno", "Morondava", "Betioky",
    "Maintirano", "Tsiroanomandidy", "Bealanana", "Miarinarivo", "Mandritsara",
    "Befandriana", "Ambalavao", "Ikongo", "Vavatenina", "Belo-sur-Tsiribihina"
};
const char *hopitaux[15] = {
    "Antananarivo", "Toamasina", "Fianarantsoa", "Mahajanga", "Toliara",
    "Antsiranana", "Ambatondrazaka", "Moramanga", "Mananjary", "Ambositra",
    "Farafangana", "Nosy Be", "Antalaha", "Sambava", "Marovoay",
    "Soavinandriana", "Ambanja", "Manakara", "Antsirabe", "Ihosy",
    "Miandrivazo", "Bekily", "Vohipeno", "Morondava", "Betioky",
    "Maintirano", "Tsiroanomandidy", "Bealanana", "Miarinarivo", "Mandritsara",
    "Befandriana", "Ambalavao", "Ikongo", "Vavatenina", "Belo-sur-Tsiribihina"
};

Route* creer_route() {
    int proba_creer_route = rand() % 2;
    if (proba_creer_route == 0)
        return NULL;

    Route* route = malloc(sizeof(Route));
    if (!route) return NULL;

    route->distance = rand() % 191 + 10;
    route->capacite_circulation = route->distance * 2;
    route->vehicules_routes = rand() % (route->capacite_circulation + 1);
    route->fluide = rand() % 2;
    route->priorite = rand() % 2;
    route->securise = rand() % 2;

    int etat = rand() % 3;
    route->etat = (EtatRoute)etat;
    route->est_endommage = (etat != NON_ENDOMMAGEE);

    return route;
}

void generer_sommets(Graphe *g) {
    for (int i = 0; i < g->Ordre; i++) {
        if (i < 35) {
            strcpy(g->noeud[i].sommet.nom, villes[i]);
        } else {
            sprintf(g->noeud[i].sommet.nom, "Ville%d", i);
        }
        g->noeud[i].liste_adjacence = NULL;
        g->noeud[i].sommet.est_hopital = rand() % 2;
    }
}


void generer_graphe_avec_routes(Graphe *g, int nb_routes_max) {
    int compteur_routes = 0;
    while (compteur_routes < nb_routes_max) {
        int src = rand() % g->Ordre;
        int dest;
        do {
            dest = rand() % g->Ordre;
        } while (dest == src);

        Route *route = creer_route();
        if (route != NULL) {
            route->destination = dest;
            route->frere = g->noeud[src].liste_adjacence;
            g->noeud[src].liste_adjacence = route;
            compteur_routes++;
        }
    }
}

