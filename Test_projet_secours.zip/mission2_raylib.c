// mission2_raylib.c: visualisation de la Mission 2 (groupes de connexité) avec Raylib
#include "raylib.h"
#include "librarie.h"
#include <math.h>
#include <stdbool.h>

#define SCREEN_WIDTH 1000
#define SCREEN_HEIGHT 800
#define RADIUS 10

// Palette de couleurs pour les différents groupes (8 couleurs max)
static const Color comp_colors[] = { RED, GREEN, BLUE, ORANGE, PURPLE, GOLD, MAROON, DARKBLUE };

// DFS pour assigner un identifiant de composante
static void dfs_assign(Graphe *g, int v, bool visited[], int comp[], int cid) {
    visited[v] = true;
    comp[v] = cid;
    for (Route *r = g->noeud[v].liste_adjacence; r; r = r->frere) {
        int u = r->destination;
        if (r->etat != DETRUITE && !visited[u]) {
            dfs_assign(g, u, visited, comp, cid);
        }
    }
}

// Affiche les composantes connexes en couleur
void afficher_mission2_raylib(Graphe *g) {
    int comp[N_SOMMETS];
    bool visited[N_SOMMETS] = { false };
    int cid = 0;

    // Initialisation
    for (int i = 0; i < g->Ordre; i++) comp[i] = -1;

    // Calcul des composantes
    for (int i = 0; i < g->Ordre; i++) {
        if (!visited[i]) {
            dfs_assign(g, i, visited, comp, cid);
            cid++;
        }
    }

    // Calcul des positions sur un cercle
    Vector2 positions[N_SOMMETS];
    float angle_step = 2 * PI / g->Ordre;
    float centerX = SCREEN_WIDTH / 2;
    float centerY = SCREEN_HEIGHT / 2;
    float rayon = 300;
    for (int i = 0; i < g->Ordre; i++) {
        positions[i].x = centerX + rayon * cosf(i * angle_step);
        positions[i].y = centerY + rayon * sinf(i * angle_step);
    }

    // Initialisation de la fenêtre
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Mission 2 - Groupes connexes");
    SetTargetFPS(60);

    // Boucle de rendu
    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE);

        // Dessiner les arêtes en gris clair
        for (int i = 0; i < g->Ordre; i++) {
            for (Route *r = g->noeud[i].liste_adjacence; r; r = r->frere) {
                int j = r->destination;
                DrawLineEx(positions[i], positions[j], 1, LIGHTGRAY);
            }
        }

        // Dessiner les sommets colorés selon leur composante
        for (int i = 0; i < g->Ordre; i++) {
            Color c = comp_colors[ comp[i] % (sizeof(comp_colors)/sizeof(comp_colors[0])) ];
            DrawCircleV(positions[i], RADIUS, c);
            DrawText(g->noeud[i].sommet.nom,
                     positions[i].x + RADIUS,
                     positions[i].y - RADIUS,
                     10, BLACK);
        }

        EndDrawing();
    }

    CloseWindow();
}
