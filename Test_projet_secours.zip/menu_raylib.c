// menu_raylib.c : interface menu pour sélectionner chaque mission Raylib
#include "raylib.h"
#include "librarie.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#define MENU_WIDTH      400
#define MENU_HEIGHT     500
#define BUTTON_WIDTH    300
#define BUTTON_HEIGHT   50
#define BUTTON_PADDING  20
#define MENU_FONT_SIZE  16  // Taille de police réduite pour tenir dans le bouton
#define TEXT_PADDING    10  // Marge à gauche du texte

// Affiche un bouton et retourne true si cliqué
static bool DrawButton(const Rectangle *btnRec, const char *label, Font font) {
    Vector2 mouse = GetMousePosition();
    bool hovered = CheckCollisionPointRec(mouse, *btnRec);
    Color btnColor = hovered ? LIGHTGRAY : GRAY;
    DrawRectangleRec(*btnRec, btnColor);

    // Calcul du positionnement à gauche avec marge
    Vector2 textSize = MeasureTextEx(font, label, MENU_FONT_SIZE, 1);
    Vector2 textPos = {
        btnRec->x + TEXT_PADDING,
        btnRec->y + (btnRec->height - textSize.y) * 0.5f
    };
    DrawTextEx(font, label, textPos, MENU_FONT_SIZE, 1, BLACK);

    if (hovered && IsMouseButtonReleased(MOUSE_LEFT_BUTTON)) return true;
    return false;
}

void afficher_menu_raylib(Graphe *g) {
    const char *btnLabels[] = {
        "Mission 1: Accessibilite",
        "Mission 2: Groupes connexes",
        "Mission 3: Plus court chemin",
        "Mission 4: Routes a securiser",
        "Quitter"
    };

    const int btnCount = sizeof(btnLabels)/sizeof(btnLabels[0]);

    Font font = GetFontDefault();

    bool running = true;
    while (running) {
        InitWindow(MENU_WIDTH, MENU_HEIGHT, "Menu - Visualisation Missions");
        SetTargetFPS(60);

        int selected = -1;
        Rectangle btnRecs[5];
        for (int i = 0; i < btnCount; i++) {
            btnRecs[i].width  = BUTTON_WIDTH;
            btnRecs[i].height = BUTTON_HEIGHT;
            btnRecs[i].x      = (MENU_WIDTH - BUTTON_WIDTH) * 0.5f;
            btnRecs[i].y      = BUTTON_PADDING + i * (BUTTON_HEIGHT + BUTTON_PADDING);
        }

        while (!WindowShouldClose() && selected < 0) {
            BeginDrawing();
            ClearBackground(RAYWHITE);
            for (int i = 0; i < btnCount; i++) {
                if (DrawButton(&btnRecs[i], btnLabels[i], font)) {
                    selected = i;
                }
            }
            EndDrawing();
        }
        CloseWindow();

        if (selected < 0 || selected == btnCount - 1) break;

        switch (selected) {
            case 0: afficher_mission1_raylib(g, 0); break;
            case 1: afficher_mission2_raylib(g);    break;
            case 2: afficher_mission3_raylib(g, 0, 1); break;
            case 3: afficher_mission4_raylib(g);   break;
        }
    }
}
