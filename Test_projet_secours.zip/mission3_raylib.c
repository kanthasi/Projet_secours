// mission3_raylib.c: visualisation de la Mission 3 (plus court chemin) avec Raylib
#include "raylib.h"
#include "librarie.h"
#include <math.h>
#include <stdbool.h>

#define SCREEN_WIDTH 1000
#define SCREEN_HEIGHT 800
#define RADIUS 10

// Recherche du sommet non visité avec la distance la plus faible
static int Sommet_DistanceMinimaleLocal(int distance[], bool visited[], int ordre) {
    int min = Infini;
    int idx = -1;
    for (int i = 0; i < ordre; i++) {
        if (!visited[i] && distance[i] < min) {
            min = distance[i];
            idx = i;
        }
    }
    return idx;
}

// Dijkstra sur une matrice d'adjacence
static void DijkstraLocal(Route *matrice[N_SOMMETS][N_SOMMETS], int ordre,
                          int start, int dist[], int pred[]) {
    for (int i = 0; i < ordre; i++) {
        dist[i] = Infini;
        pred[i] = -1;
    }
    dist[start] = 0;
    bool visited[N_SOMMETS] = { false };

    for (int k = 0; k < ordre; k++) {
        int u = Sommet_DistanceMinimaleLocal(dist, visited, ordre);
        if (u < 0) break;
        visited[u] = true;
        for (int v = 0; v < ordre; v++) {
            Route *r = matrice[u][v];
            if (r && !visited[v] && r->etat != DETRUITE) {
                int nd = dist[u] + r->distance;
                if (nd < dist[v]) {
                    dist[v] = nd;
                    pred[v] = u;
                }
            }
        }
    }
}

// Reconstruit le chemin depuis l'arrivée
static int Chemin_DijkstraLocal(int arrivee, int pred[], int chemin[]) {
    int len = 0;
    for (int cur = arrivee; cur != -1; cur = pred[cur]) {
        chemin[len++] = cur;
    }
    // Inversion
    for (int i = 0; i < len/2; i++) {
        int tmp = chemin[i];
        chemin[i] = chemin[len-1-i];
        chemin[len-1-i] = tmp;
    }
    return len;
}

// Affiche le plus court chemin entre start et arrivee
void afficher_mission3_raylib(Graphe *g, int start, int arrivee) {
    // Construction de la matrice d'adjacence
    Route *matrice[N_SOMMETS][N_SOMMETS] = { { NULL } };
    for (int i = 0; i < g->Ordre; i++) {
        for (Route *r = g->noeud[i].liste_adjacence; r; r = r->frere) {
            matrice[i][r->destination] = r;
        }
    }
    // Exécution de Dijkstra
    int dist[N_SOMMETS];
    int pred[N_SOMMETS];
    int chemin[N_SOMMETS];
    DijkstraLocal(matrice, g->Ordre, start, dist, pred);
    int len = Chemin_DijkstraLocal(arrivee, pred, chemin);

    // Calcul des positions sur un cercle
    Vector2 pos[N_SOMMETS];
    float angle_step = 2 * PI / g->Ordre;
    float cx = SCREEN_WIDTH/2.0f;
    float cy = SCREEN_HEIGHT/2.0f;
    float rad = 300.0f;
    for (int i = 0; i < g->Ordre; i++) {
        pos[i].x = cx + rad * cosf(i * angle_step);
        pos[i].y = cy + rad * sinf(i * angle_step);
    }

    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Mission 3 - Plus Court Chemin");
    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE);

        // Arêtes en gris clair
        for (int i = 0; i < g->Ordre; i++) {
            for (Route *r = g->noeud[i].liste_adjacence; r; r = r->frere) {
                int j = r->destination;
                DrawLineEx(pos[i], pos[j], 1, LIGHTGRAY);
            }
        }

        // Chemin le plus court en vert épais
        for (int k = 0; k < len-1; k++) {
            int u = chemin[k];
            int v = chemin[k+1];
            DrawLineEx(pos[u], pos[v], 3, GREEN);
        }

        // Sommets : bleu foncé, verts si sur le chemin
        for (int i = 0; i < g->Ordre; i++) {
            Color c = DARKBLUE;
            for (int k = 0; k < len; k++) {
                if (chemin[k] == i) { c = GREEN; break; }
            }
            DrawCircleV(pos[i], RADIUS, c);
            DrawText(g->noeud[i].sommet.nom,
                     pos[i].x + RADIUS,
                     pos[i].y - RADIUS,
                     10, BLACK);
        }

        EndDrawing();
    }

    CloseWindow();
}
