#ifndef LIBRARIE_H
#define LIBRARIE_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "raylib.h"
#include  <math.h>

#define MAX_RESSOURCES 10
#define MAX_NOM 30
#define Infini 200
#define N_SOMMETS 50

static const char *villes[50] = {
    "Antananarivo", "Toamasina", "Fianarantsoa", "Mahajanga", "Toliara",
    "Antsiranana", "Ambatondrazaka", "Moramanga", "Mananjary", "Ambositra",
    "Farafangana", "Nosy Be", "Antalaha", "Sambava", "Marovoay",
    "Soavinandriana", "Ambanja", "Manakara", "Antsirabe", "Ihosy",
    "Miandrivazo", "Bekily", "Vohipeno", "Morondava", "Betioky",
    "Maintirano", "Tsiroanomandidy", "Bealanana", "Miarinarivo", "Mandritsara",
    "Befandriana", "Ambalavao", "Ikongo", "Vavatenina", "Belo-sur-Tsiribihina",    "CHU Joseph Ravoahangy", "CHU Befelatanana", "Hôpital Androva", "CHU Toamasina", "Hôpital Fianarantsoa",
    "Hôpital Ambanja", "Hôpital Toliara", "Hôpital Sambava", "Hôpital Antsirabe", "Hôpital Manakara",
    "Hôpital Morondava", "Hôpital Fort Dauphin", "Hôpital Maintirano", "Hôpital Nosy Be", "Hôpital Tsiroanomandidy"
};

/*static const char *hopitaux[15] = {
    "CHU Joseph Ravoahangy", "CHU Befelatanana", "Hôpital Androva", "CHU Toamasina", "Hôpital Fianarantsoa",
    "Hôpital Ambanja", "Hôpital Toliara", "Hôpital Sambava", "Hôpital Antsirabe", "Hôpital Manakara",
    "Hôpital Morondava", "Hôpital Fort Dauphin", "Hôpital Maintirano", "Hôpital Nosy Be", "Hôpital Tsiroanomandidy"
};
*/



typedef struct {
    char nom[20];
    int poids;
    int valeur_nutritive;
    int priorite;
} Ressource;

typedef enum { MEDICAMENT, NOURRITURE } TypeRessource;

typedef struct {
    int medicament;
    int nourriture;
    int eau;
    int equipement;
} Ressources;

typedef struct {
    char nom[MAX_NOM];
    bool est_hopital;
    int nb_habitants;
    int nb_malade;
    int place_disponible;
    Ressource stock[MAX_RESSOURCES];
    int nb_ressources;
    int nombre;
} Sommet;

typedef enum {
    DETRUITE,
    ENDOMMAGEE,
    NON_ENDOMMAGEE
} EtatRoute;

typedef struct Route {
    int distance;
    EtatRoute etat;
    int capacite_circulation;
    bool fluide;
    bool priorite;
    bool est_endommage;
    bool securise;
    int vehicules_routes;
    int destination;
    struct Route *frere;
} Route;

typedef struct {
    float charge_max;
    float charge_actuelle;
    bool est_en_service;
} Vehicule_Secours;

typedef struct {
    Sommet sommet;
    Route *liste_adjacence;
} NoeudGraphe;

typedef struct {
    NoeudGraphe noeud[N_SOMMETS];
    int Ordre;
} Graphe;

typedef struct {
    int depart;
    int arrivee;
    int distance;
} RouteCandidate;

static inline void compute_positions(Graphe *g, Vector2 positions[], int screen_w, int screen_h) {
    float angle_step = 2 * PI / g->Ordre;
    float cx = screen_w * 0.5f;
    float cy = screen_h * 0.5f;
    float r  = (screen_w < screen_h ? screen_w : screen_h) * 0.4f;
    for (int i = 0; i < g->Ordre; i++) {
        positions[i].x = cx + r * cosf(i * angle_step);
        positions[i].y = cy + r * sinf(i * angle_step);
    }
}



// Prototypes
Route* creer_route();
void generer_sommets(Graphe *g);
void generer_graphe_avec_routes(Graphe *g, int nb_routes_max);



// Mission 1
void afficherRoutes(Graphe *g);
void Afficher_chemin_accessible(Graphe *g, int num_sommet, bool parcouru[N_SOMMETS]);
void afficher_sommets_inaccessibles(Graphe *g, bool parcouru[N_SOMMETS]);
// Mission 2
void trouverGroupesChemins(Graphe* g);

//mission3
int Sommet_DistanceMinimale(int distance[], bool distance_trouvee[]);
void Djikstra(Route *graphe[N_SOMMETS][N_SOMMETS], int Distance[], int SommetDepart, int Predecesseur[]);
int Chemin_Djikstra(int SommetArrivee, int Predecesseur[], int chemin[]);
void Endommager(Route *graphe[N_SOMMETS][N_SOMMETS]);
void Djikstra_endommagement(Route *graphe[N_SOMMETS][N_SOMMETS], int Distance[], int SommetDepart, int Predecesseur[]);
void afficher_plus_court_chemin(Graphe *g, int sommet_depart, int sommet_arrivee);

// mission4
int comparer_routes(const void *a, const void *b);
void fusion_ensembles(int parent[], int x, int y);
int trouver_representant(int parent[], int sommet) ;
void identifier_routes_a_securiser(Graphe *graphe);


//raylib 
void afficher_graphe_raylib(Graphe *g);
static void mark_accessible(Graphe *g, int num_sommet, bool visited[]);
void afficher_mission1_raylib(Graphe *g, int sommet_depart);
void afficher_mission2_raylib(Graphe *g);
void afficher_mission3_raylib(Graphe *g, int start, int arrivee);

void afficher_mission4_raylib(Graphe *g) ;

void afficher_menu_raylib(Graphe *g);
#endif

