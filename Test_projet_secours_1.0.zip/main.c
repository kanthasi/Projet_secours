#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "librarie.h"


#define NB_VILLES 70
#define NB_ROUTES 50
#define Infini 200
int main() {
    srand(time(NULL));

    Graphe g;
    g.Ordre = NB_VILLES;

    generer_sommets(&g);
    generer_graphe_avec_routes(&g, NB_ROUTES);

    // Mission 1 :
    afficherRoutes(&g);

bool parcouru[N_SOMMETS] = { false };
int sommet_depart = 0;

Afficher_chemin_accessible(&g, sommet_depart, parcouru);
afficher_sommets_inaccessibles(&g, parcouru);

//mission2
    printf("=== Groupes de sommets accessibles librement (Mission 2) ===\n\n");
    trouverGroupesChemins(&g);
//mission4
identifier_routes_a_securiser(&g);


// Mission 3
// ajouter quelle ville choisir : plus tard
afficher_plus_court_chemin(&g, sommet_depart, 1); 

//raylib
// Visualisation graphique du graphe
//afficher_graphe_raylib(&g);
//afficher_mission1_raylib(&g, 15);

//afficher_mission2_raylib(&g);
//afficher_mission3_raylib(&g, sommet_depart,1);
//afficher_mission4_raylib(&g);

afficher_menu_raylib(&g);
 return 0;
}
