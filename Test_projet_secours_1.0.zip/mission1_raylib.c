// mission1_raylib.c: visualisation de la Mission 1 avec bouton pour inaccessibles
#include "raylib.h"
#include "librarie.h"
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>



#define SCREEN_WIDTH 1000
#define SCREEN_HEIGHT 800
#define RADIUS 10
#define INFO_HEIGHT 30

// Marque les sommets accessibles depuis "num_sommet"
static void mark_accessible(Graphe *g, int num_sommet, bool visited[]) {
    visited[num_sommet] = true;
    Route *route = g->noeud[num_sommet].liste_adjacence;
    while (route) {
        int dest = route->destination;
        if (!visited[dest]
            && route->etat != DETRUITE
            && route->vehicules_routes < route->capacite_circulation) {
            mark_accessible(g, dest, visited);
        }
        route = route->frere;
    }
}

void afficher_mission1_raylib(Graphe *g, int sommet_depart) {
    bool visited[N_SOMMETS] = { false };
    mark_accessible(g, sommet_depart, visited);

    // Calcul des positions des sommets
    Vector2 positions[N_SOMMETS];
    compute_positions(g, positions, SCREEN_WIDTH, SCREEN_HEIGHT);

    // Bouton Inaccessibles
    Rectangle btnInac = { 10, 10, 200, 30 };
    bool showInac = false;

    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Mission 1 - Accessibilite");
    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        // Clic sur bouton
        if (IsMouseButtonReleased(MOUSE_LEFT_BUTTON)) {
            Vector2 mp = GetMousePosition();
            if (CheckCollisionPointRec(mp, btnInac)) showInac = !showInac;
        }
        // Esc pour fermer
        if (IsKeyPressed(KEY_ESCAPE)) break;

        BeginDrawing();
        ClearBackground(RAYWHITE);

        // Dessiner bouton
        DrawRectangleRec(btnInac, showInac ? LIGHTGRAY : GRAY);
        DrawText("> inaccessibles", btnInac.x + 10, btnInac.y + 8, 20, BLACK);

        // Dessiner les routes
        for (int i = 0; i < g->Ordre; i++) {
            for (Route *r = g->noeud[i].liste_adjacence; r; r = r->frere) {
                int j = r->destination;
                Color color = (r->etat == DETRUITE) ? RED
                             : (visited[i] && visited[j]) ? GREEN
                             : ORANGE;
                DrawLineEx(positions[i], positions[j], 2, color);
            }
        }

        // Dessiner les sommets
        for (int i = 0; i < g->Ordre; i++) {
            Color col = visited[i] ? GREEN : RED;
            DrawCircleV(positions[i], RADIUS, col);
            DrawText(g->noeud[i].sommet.nom,
                     positions[i].x + RADIUS,
                     positions[i].y - RADIUS,
                     10, BLACK);
        }

        // Afficher liste inaccessibles si demandé
        if (showInac) {
            DrawRectangle(10, 50, 200, SCREEN_HEIGHT - 60, Fade(LIGHTGRAY, 0.8f));
            DrawText("Inaccessibles:", 15, 60, 14, BLACK);
            int y = 80;
            for (int i = 0; i < g->Ordre; i++) {
                if (!visited[i]) {
                    DrawText(g->noeud[i].sommet.nom, 15, y, 12, BLACK);
                    y += 16;
                    if (y > SCREEN_HEIGHT - 10) break;
                }
            }
        }

        EndDrawing();
    }

    CloseWindow();
}
